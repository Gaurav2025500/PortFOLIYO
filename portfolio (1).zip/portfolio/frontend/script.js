// Loads profile.json and builds the page. Edit profile.json to change content.
const $ = (id) => document.getElementById(id);

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function addLink(parent, label, url, className) {
  if (!url) return;
  const a = el("a", label, className);
  a.href = url;
  a.target = "_blank";
  a.rel = "noopener noreferrer";
  parent.appendChild(a);
}

async function loadProfile() {
  // Uses the backend API when it is running, otherwise the static JSON file.
  try {
    const res = await fetch("/api/profile");
    if (res.ok) return await res.json();
  } catch (e) { /* fall through */ }
  const res = await fetch("profile.json");
  return res.json();
}

function renderSkills(skills) {
  const grid = $("skillGrid");
  const panel = $("topics");
  let active = null;

  skills.forEach((skill) => {
    const btn = el("button", null, "skill");
    btn.type = "button";
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", "topics");
    btn.appendChild(el("strong", skill.name));
    btn.appendChild(el("span", skill.topics.length + " topics"));
    btn.addEventListener("click", () => {
      if (active === btn) {
        btn.setAttribute("aria-expanded", "false");
        panel.hidden = true;
        active = null;
        return;
      }
      if (active) active.setAttribute("aria-expanded", "false");
      btn.setAttribute("aria-expanded", "true");
      active = btn;
      $("topicsTitle").textContent = skill.name + ": topics I have learned";
      $("topicsList").replaceChildren(...skill.topics.map((t) => el("li", t)));
      panel.hidden = false;
      panel.style.animation = "none";
      void panel.offsetWidth;
      panel.style.animation = "";
    });
    grid.appendChild(btn);
  });
}

function renderProjects(projects) {
  $("projectList").replaceChildren(...projects.map((p) => {
    const card = el("article", null, "project");
    card.appendChild(el("h3", p.title));
    card.appendChild(el("p", p.description));
    const tech = el("ul", null, "tech");
    p.tech.forEach((t) => tech.appendChild(el("li", t)));
    card.appendChild(tech);
    const links = el("div", null, "project-links");
    addLink(links, "Live demo", p.link);
    addLink(links, "Source code", p.repo);
    if (links.children.length) card.appendChild(links);
    return card;
  }));
}

function renderEducation(items) {
  $("educationList").replaceChildren(...items.map((e) => {
    const box = el("div", null, "edu");
    box.appendChild(el("h3", e.school));
    box.appendChild(el("p", e.degree));
    box.appendChild(el("p", e.year));
    return box;
  }));
}

loadProfile().then((d) => {
  const initials = d.name.split(" ").filter((_, i, a) => i === 0 || i === a.length - 1).map((w) => w[0]).join("");
  document.title = d.name + " | " + d.role;
  $("mark").textContent = initials;
  $("brandName").textContent = d.name;
  $("name").textContent = d.name;
  $("role").textContent = d.role;
  $("tagline").textContent = d.tagline;
  $("location").textContent = d.location;
  const edu = d.education[0];
  $("gDegree").textContent = edu.degree;
  $("gSchool").textContent = edu.school;
  $("gYear").textContent = edu.year;
  if (d.links.linkedin) {
    const b = $("heroLinkedin");
    b.href = d.links.linkedin; b.target = "_blank"; b.rel = "noopener noreferrer"; b.textContent = "LinkedIn";
  }
  const contact = $("contactLinks");
  addLink(contact, "LinkedIn", d.links.linkedin, "btn primary");
  addLink(contact, "GitHub", d.links.github, "btn ghost");
  addLink(contact, "Email", d.links.email ? "mailto:" + d.links.email : "", "btn ghost");
  renderSkills(d.skills);
  renderProjects(d.projects);
  renderEducation(d.education);
  $("copy").textContent = "© " + new Date().getFullYear() + " " + d.name;
}).catch(() => {
  $("name").textContent = "Could not load profile.json";
});

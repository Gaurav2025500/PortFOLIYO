const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND = path.join(__dirname, "..", "frontend");

// Serve the website files
app.use(express.static(FRONTEND));

// API: returns the same data the page displays
app.get("/api/profile", (req, res) => {
  fs.readFile(path.join(FRONTEND, "profile.json"), "utf8", (err, data) => {
    if (err) return res.status(500).json({ error: "Could not read profile data" });
    res.json(JSON.parse(data));
  });
});

app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));

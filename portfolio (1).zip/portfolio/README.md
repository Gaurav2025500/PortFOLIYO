# Portfolio – Gaurav Ayodhya Shivhare

```
portfolio/
├── frontend/   index.html, style.css, script.js, profile.json
└── backend/    server.js, package.json
```

## Run in VS Code
1. Open the `portfolio` folder in VS Code.
2. Terminal:
   ```
   cd backend
   npm install
   npm start
   ```
3. Open http://localhost:3000

Frontend only: right-click `frontend/index.html` and choose "Open with Live Server".

## Change content
Edit `frontend/profile.json`: add your LinkedIn, GitHub, email, and project links.

## Host on GitHub Pages
Push this folder to GitHub, then Settings > Pages and publish the `frontend` folder
(or copy the frontend files to the repo root). GitHub Pages hosts static files only,
so the page reads `profile.json` directly there. The backend is for running locally
or on a Node host such as Render.
